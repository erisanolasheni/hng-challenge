<?php
$heads = '<!DOCTYPE html>

	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
	<link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700i" rel="stylesheet">
</head>';

	$sub_heads='<div class="wrapper">
		<div class="head">Transfer Rules <i class="menu fa fa-bars"></i></div>
		<ul class="side-nav">
			<li><a href="#"><i class="fa fa-dashboard"></i>&nbsp; Dashboard</a></li>
			<li><a href="#" class="active"><i class="fa fa-paste"></i>&nbsp; Transaction Logs</a></li>
			<li><a href="#"><i class="fa fa-money"></i>&nbsp; Wallets</a></li>
			<li><a href="#"><i class="fa fa-user"></i>&nbsp; Settings</a></li>
			<li><a href="#"><i class="fa fa-sign-out"></i>&nbsp; Sign Out</a></li>

		</ul>';
$foots = '<div class="foot">&copy;&nbsp;Copyright Team-calculon</div>
	</div>
</html>';
?>